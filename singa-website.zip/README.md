# 🦁 Singa Website

Website sederhana bertema singa (king of jungle).

## Fitur
- Desain warm (kuning/oranye)
- Interaksi tombol auman singa
- Struktur sederhana untuk pemula

## Cara Menjalankan
Buka file `index.html` di browser.

## Upload ke GitHub
1. Extract zip
2. Upload ke repository
3. Commit 🚀
