function roar() {
    alert("ROARRR!! 🦁 Sang Raja Hutan!");
}
